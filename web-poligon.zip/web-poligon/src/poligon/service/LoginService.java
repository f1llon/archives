package poligon.service;

import poligon.entity.Credential;

import java.util.Optional;

/**
 * Created by dio on 28.12.14.
 */
public class LoginService {

	private volatile boolean isTokenActive = false;

	public Optional<String> createToken(Credential credential) {
		if ("dio@gmail.com".equals(credential.getUser()) && "123456".equals(credential.getPassword())) {
			isTokenActive = true;
			return Optional.of("token");
		} else {
			return Optional.empty();
		}
	}

	public boolean validateToken(String token) {
		return isTokenActive && "token".equals(token);
	}

	public void deactivateToken(String token) {
		isTokenActive = false;
	}
}
