package poligon.service;

import poligon.entity.User;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by dio on 27.12.14.
 */
public class UserService {

	private final ConcurrentMap<Long, User> users = new ConcurrentHashMap<>();
	private final AtomicLong ids = new AtomicLong(100);

	public void put(User user) {
		if (user.getId() == 0) {
			user = new User(ids.getAndIncrement(), user.getFirstName(), user.getSecondName(), user.getUserName());
		}
		users.put(user.getId(), user);
	}

	public Collection<User> all() {
		return users.values();
	}

	public void remove(long id) {
		users.remove(id);
	}

}
