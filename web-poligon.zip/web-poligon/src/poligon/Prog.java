package poligon;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import poligon.entity.Credential;
import poligon.entity.User;
import poligon.service.LoginService;
import poligon.service.UserService;
import poligon.transformer.ResourceTransformer;
import spark.Request;
import spark.Response;

import java.util.Optional;

import static spark.Spark.*;
import static spark.SparkBase.externalStaticFileLocation;

public class Prog {
	public static void main(String[] args) {

		final LoginService loginService = new LoginService();

		final UserService userService = new UserService();
		userService.put(new User(1, "Dio", "Eraclea", "Solist"));
		userService.put(new User(2, "Cloud", "Strike", "Big brother"));
		userService.put(new User(3, "Ao", "Snow", "---"));

		final Gson gson = new GsonBuilder().create();

		final ResourceTransformer resourceTransformer = new ResourceTransformer();

		externalStaticFileLocation("public");

		before("/rest-api/*", (req, res) -> filter(loginService, req, res, false));
		before("/logout", (req, res) -> filter(loginService, req, res, true));
		before("/", (req, res) -> filter(loginService, req, res, true));

		get("/login", (req, res) -> "resources/login.html", resourceTransformer);
		post("/token", (req, res) -> token(req, res, loginService, gson));

		get("/", (req, res) -> "resources/index.html", resourceTransformer);
		get("/rest-api/users.json", (req, res) -> userService.all(), gson::toJson);
		post("/rest-api/user-submit", (req, res) -> {
			final User user = gson.fromJson(req.body(), User.class);
			userService.put(user);
			return userService.all();
		}, gson::toJson);
		post("/rest-api/remove-user", (req, res) -> {
			userService.remove(Long.parseLong(req.body()));
			return userService.all();
		}, gson::toJson);
		get("/logout", (req, res) -> {
			final String token = req.cookie("token");
			loginService.deactivateToken(token);
			res.redirect("/login");
			return res;
		});
	}

	private static void filter(LoginService loginService, Request req, Response res, boolean redirectToLogon) {
		final String token = req.cookie("token");
		if (!loginService.validateToken(token)) {
			if (redirectToLogon) {
				res.redirect("/login");
			}
			halt(401);
		}
	}

	private static Response token(Request req, Response res, LoginService loginService, Gson gson) {
		final Credential credential = gson.fromJson(req.body(), Credential.class);
		final Optional<String> token = loginService.createToken(credential);
		if (token.isPresent()) {
			res.cookie("token", token.get(), 60 * 60 * 24);
			res.cookie("user", credential.getUser(), 60 * 60 * 24 * 7);
			return res;
		} else {
			halt(401, "Login failed");
			return null;
		}
	}
}
