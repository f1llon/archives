package poligon.transformer;

import spark.ResponseTransformer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by dio on 28.12.14.
 */
public class ResourceTransformer implements ResponseTransformer {

	@Override
	public String render(Object model) throws Exception {
		return Files.readAllLines(Paths.get(model.toString())).stream().collect(Collectors.joining());
	}
}
