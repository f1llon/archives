/**
 * Created by dio on 28.12.14.
 */

var webPoligon = angular.module('webPoligonLogin', ['ngCookies']);

webPoligon.controller('webPoligonLoginController', function ($scope, $http, $window, $cookies) {
    delete $cookies['token'];
    $scope.loginForm = {};
    if ($cookies.user) {
        $scope.loginForm.user = $cookies.user;
        document.querySelector('#inputPassword').focus();
    } else {
        document.querySelector('#inputEmail').focus();
    }
    $scope.loginForm.submitLogin = function (item, event) {
        $http.post('token', $scope.loginForm, {})
            .success(function (data, status, headers, config) {
                console.log('token response ' + status);
                $window.location.href = '/';
            })
            .error(function (data, status, headers, config) {
                alert("Login failed");
            });
    };
});
