/**
 * Created by dio on 27.12.14.
 */

var webPoligon = angular.module('webPoligon', ['ngCookies']);

webPoligon.controller('webPoligonController', function ($scope, $http, $cookies, $window) {
    $scope.account = $cookies.user;
    $scope.orderProp = 'id';
    $scope.userForm = {};

    $http.get('rest-api/users.json')
        .success(function (data) {
            $scope.users = data;
        })
        .error(function (data) {
            console.log('1');
            $window.location.href = '/login';
        });

    $scope.userForm.submitUserForm = function (item, event) {
        $http.post('rest-api/user-submit', $scope.userForm, {})
            .success(function (data, status, headers, config) {
                $scope.setUserForm({});
                $scope.users = data;
            })
            .error(function (data, status, headers, config) {
                console.log('2');
                $window.location.href = '/login';
            });
    };

    $scope.removeUser = function (user) {
        $http.post('rest-api/remove-user', user.id, {})
            .success(function (data, status, headers, config) {
                $scope.setUserForm({});
                $scope.users = data;
            })
            .error(function (data, status, headers, config) {
                console.log('3');
                $window.location.href = '/login';
            });
    };

    $scope.selectRow = function (user) {
        if ($scope.lastSelected) {
            //unselect last selected row
            $scope.lastSelected.selected = '';
        }
        if ($scope.lastSelected == this) {
            //unselect this row, clear submit form
            $scope.lastSelected = null;
            user = {};
        } else {
            //select this row
            this.selected = 'selected';
            $scope.lastSelected = this;
        }
        $scope.setUserForm(user);
    };

    $scope.setUserForm = function (user) {
        $scope.userForm.id = user.id;
        $scope.userForm.firstName = user.firstName;
        $scope.userForm.secondName = user.secondName;
        $scope.userForm.userName = user.userName;
    }
});